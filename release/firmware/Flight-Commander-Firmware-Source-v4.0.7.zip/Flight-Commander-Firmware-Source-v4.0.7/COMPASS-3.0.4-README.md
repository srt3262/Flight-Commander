# Flight Commander Firmware 3.0.4 — MICOAIR743 Compass Bench Build

This source is based on the coordinated Flight Commander 3.0.3 firmware source
and contains the first end-to-end MICOAIR743 onboard IST8310 correction.

Key changes:
- IST8310 reset, WHO_AM_I verification, data-ready gating, single-shot conversion,
  timeout recovery, and full-scale rejection.
- Fixed MICOAIR743 onboard chip-to-body transform: (-native Y, native X, -native Z).
- 0-degree alignment means no additional user rotation; target Default also resolves
  to zero additional rotation.
- Failed or implausible calibration candidates are rejected without overwriting the
  previous valid calibration.
- Invalid saved gains are not applied, failed reads do not inject a zero vector, and
  compass health includes sample freshness.

Build with the pinned Arm GNU Toolchain 13.2.1:

    flight-commander/build-micoair743.sh /path/to/new/build-directory

Use Full chip erase for the first flash so invalid calibration values from earlier
development firmware are not retained.
