# Flight Commander Firmware 3.0.7 — Official MICOAIR743 Compass Baseline

Physical propeller-off testing confirmed this onboard IST8310 mapping against
the flight-controller heading, level yaw, pitch, and roll:

    X = -native Y
    Y = -native X
    Z =  native Z

The onboard compass user alignment remains CW 0 degrees. This transform is
target-specific and must not be applied to external UART/I2C or DroneCAN
compasses. Future MICOAIR743 development must preserve this contract.
