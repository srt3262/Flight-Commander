# Flight Commander Firmware Extension Protocol

Flight Commander Firmware retains INAV's standard MSP identity and commands.
Fork-specific behavior is negotiated through optional MSPv2 messages so an
older configurator can continue to use the controller safely.

## Firmware information

`MSP2_FLIGHT_COMMANDER_INFO` is an outbound request/response command with ID
`0x2F00`. It has no request payload. Schema 1 returns this fixed 15-byte
little-endian payload:

| Offset | Bytes | Field |
|---:|---:|---|
| 0 | 4 | ASCII signature `FCFW` |
| 4 | 1 | payload schema version |
| 5 | 3 | Flight Commander firmware major, minor, patch |
| 8 | 3 | compatible INAV firmware major, minor, patch |
| 11 | 4 | capability bitmap, unsigned little-endian |

Unknown schema versions must not be interpreted as schema 1. A configurator
that receives an MSP error or timeout for this optional command must continue
using the normal INAV compatibility path.

## Capability bits

| Bit | Name | Meaning when set |
|---:|---|---|
| 0 | `MULTIROTOR_AUTOTUNE` | bounded multirotor AutoTune is implemented |
| 1 | `TERRAIN_WAYPOINTS` | explicit terrain-relative waypoint behavior is implemented |
| 2 | `MISSION_STREAMING` | a mission can be streamed beyond onboard waypoint storage |
| 3 | `RTK_GPS_UART` | the UART GNSS path reports RTK float/fixed states and accepts RTCM3 |
| 4 | `DRONECAN` | DroneCAN transport and node discovery are available |
| 5 | `DRONECAN_GPS` | DroneCAN GNSS and RTK status are available |
| 6 | `NATIVE_GCS_COMMANDS` | native Ground Control command handling is available |
| 7 | `PHOTO_TRIGGERS` | mission photo-trigger behavior is available |
| 8 | `DRONECAN_NODE_CONFIG` | DroneCAN node selection/configuration is writable |
| 9 | `MISSION_RESUME` | interrupted mission state can be resumed |
| 10 | `GCS_RTK_BASE` | Ground Control can provide RTCM3 base corrections |
| 11 | `HEADING_FUSION` | multiple heading sources can be validated and fused |
| 12 | `MOVING_BASELINE_YAW` | dual-GNSS moving-baseline heading is supported |

Firmware 2.0.6 returns `0x00001FFF`. Reserved bits remain zero until they are
specified and implemented.

## Additional messages

Flight Commander 2.0.6 defines these MSPv2 command IDs in the vendor-specific
`0x2F00` range:

| ID | Name | Direction | Purpose |
|---:|---|---|---|
| `0x2F00` | `INFO` | read | fork identity, version, compatibility, capabilities |
| `0x2F01` | `RTK_STATUS` | read | correction transport, fix type, counters, pending bytes |
| `0x2F02` | `DUAL_GPS_STATUS` | read | UART/DroneCAN GNSS health, fixes, positions, baseline |
| `0x2F03` | `RTCM_DATA` | write | fragmented RTCM3 input from Ground Control |
| `0x2F10` | `DRONECAN_CONFIG` | read | local node, bitrate, selected GPS/battery/mag nodes |
| `0x2F11` | `SET_DRONECAN_CONFIG` | write | update DroneCAN configuration while disarmed |
| `0x2F12` | `DRONECAN_NODES` | read | bus state and discovered-node status |
| `0x2F20` | `HEADING_CONFIG` | read | per-source priority, weight, alignment, calibration |
| `0x2F21` | `SET_HEADING_CONFIG` | write | update heading configuration while disarmed |
| `0x2F22` | `HEADING_STATUS` | read | source health, rejection, fusion, baseline, calibration |

Payload schemas and fixed sizes are declared beside their implementations in
`src/main/flight_commander`, `src/main/drivers/dronecan`, and
`src/main/fc/fc_msp.c`; those definitions are authoritative for generated
clients.

## Compatibility rules

- Standard `MSP_FC_VARIANT` remains `INAV`.
- Standard firmware compatibility remains INAV 9.1.0.
- Existing MSP commands keep their original encoding and behavior.
- New features are disabled by default and require both a capability bit and a
  versioned configuration contract.
- Capability discovery never authorizes arming or changes configuration.
