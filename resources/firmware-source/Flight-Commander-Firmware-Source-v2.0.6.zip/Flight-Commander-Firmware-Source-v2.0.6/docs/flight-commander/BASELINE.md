# Flight Commander Firmware Baseline

## Purpose

Flight Commander Firmware is a GPL-3.0 fork of INAV. The first supported
hardware target is the Aero Selfie H743 board using INAV's `MICOAIR743`
target. Development starts from a reproduced, known-good firmware image so
that every later behavior change can be reviewed as an intentional delta.

This baseline does not change flight-control behavior.

## Source provenance

| Item | Baseline |
|---|---|
| Upstream repository | `https://github.com/iNavFlight/inav.git` |
| Upstream release | INAV 9.1.0 |
| Upstream commit | `e519b69b02e27c8bdc03b4a0889f1baaae211a54` |
| Development branch | `flight-commander-0.1.x` |
| First target | `MICOAIR743` |
| Board identifier | `M743` |
| MCU | STM32H743XI |
| Compiler | Arm GNU Toolchain 13.2.1 |

INAV firmware 9.1.0 and INAV Configurator 9.1.1 are separate versioned
products. Flight Commander Firmware preserves the firmware's INAV 9.1.0
compatibility version until a coordinated protocol migration is complete.

## Reproduction result

The unmodified `MICOAIR743` target builds locally from the pinned upstream
commit.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| Official INAV 9.1.0 `MICOAIR743` HEX | 1,811,648 | `fcdc870bf11c363d0a9eda8a9513909fab23ffd4c65775317d8f7c2c0bceacfa` |
| Local unmodified `MICOAIR743` HEX | 1,811,648 | `04296b5cc2dc7b665b48475ec2b4e08f381a398d885ea453e30124f64ac45a78` |

A complete Intel HEX comparison differs only in three records containing the
embedded source/build identifier, build time, and build date. All remaining
records are identical.

The linked local ELF uses:

| Section group | Bytes |
|---|---:|
| Text | 632,843 |
| Initialized data | 11,200 |
| BSS | 111,928 |
| Total | 755,971 |

## Hardware contract

The inherited `MICOAIR743` target defines the following board resources:

- USB VCP and seven UART-backed serial ports
- BMI088 IMU on SPI2
- DPS310 barometer and onboard magnetometer bus on I2C2
- external magnetometer bus option on I2C1
- AT7456E/MAX7456 analog OSD on SPI1
- SD card logging over four-bit SDIO
- analog battery voltage and current sensing
- ten timer outputs
- DShot, ESC telemetry, and BLHeli four-way support
- MSP optical-flow and rangefinder inputs

No target pin, timer, DMA, sensor-alignment, voltage-scale, current-scale, or
default-feature value may change during the identity-only checkpoint.

## Compatibility contract

Until Flight Commander explicitly negotiates the fork extension, firmware
must continue to report the standard INAV values used by the existing app:

- MSP flight-controller variant: `INAV`
- INAV firmware compatibility version: `9.1.0`
- MSP API compatibility: 2.5
- board identifier: `M743`
- firmware target: `MICOAIR743`

Fork identity and future capabilities are exposed through the optional,
versioned `MSP2_FLIGHT_COMMANDER_INFO` extension documented in `PROTOCOL.md`.
Existing INAV tools and Flight Commander v1.9.2 remain able to configure the
controller without knowing that extension.

The identity-only 0.1.0 checkpoint advertises a zero capability bitmap. A
feature bit must not be enabled until the corresponding firmware behavior,
configuration surface, telemetry, rollback path, and tests are present.

## Feature boundaries

### Ground-station features

These belong primarily in Flight Commander and should not destabilize the
flight loop:

- polygon-based survey grid generation
- route spacing, overlap, turnaround, and completion behavior
- GIS/elevation sampling and conversion into uploaded waypoint altitudes
- mission interruption, resume, and progress controls

### Firmware-native features

These require deliberate controller changes:

- multirotor AutoTune with bounded excitation, rollback, progress reporting,
  and Blackbox evidence
- explicit terrain-relative waypoint semantics or onboard terrain data
- mission streaming when a generated survey exceeds onboard waypoint storage
- additional H7 flight-controller targets and enterprise sensor redundancy

## Development order

1. Reproduce the upstream image and preserve target behavior.
2. Add backward-compatible Flight Commander firmware identity.
3. Bench-verify sensors, ports, receiver, mixer, outputs, storage, OSD, MSP,
   MAVLink telemetry, save/reboot, and DFU recovery on `MICOAIR743`.
4. Add one firmware-native feature at a time behind capability flags.
5. Add Pixhawk/CubePilot-class targets only after the first H743 target passes
   the same build, bench, and flight gates.

## Licensing

The fork remains licensed under GNU GPL v3. INAV and earlier Cleanflight/
Baseflight copyright and license notices must be preserved. Distributed
firmware releases must provide the complete corresponding source and the same
license freedoms.
