# Flight Commander Firmware 2.0.6

## Supported target

Firmware 2.0.6 has one supported hardware target: `MICOAIR743`. It uses the
board's onboard IST8310 magnetometer on I2C2. The sensor is physically mounted
at a 90-degree clockwise yaw relative to the board axes, so firmware applies
`CW90_DEG` both as the target default and as the fallback for aircraft upgraded
from an older neutral alignment setting.

There is no `MICOAIR743_EXTMAG` build or release asset. External UART and
DroneCAN GPS/RTK modules remain supported; they are unrelated to the removed
external-compass target.

## Corresponding source

The release contains the complete corresponding source required by GPL-3.0,
including the inherited INAV 9.1.0 tree, Flight Commander modifications,
libcanard, generated DroneCAN message code, the MICOAIR743 target, build helper,
and release verifier. The archive's `RELEASE-MANIFEST.json` records the exact
source revision, reproducible build epoch, compiler, HEX filename, size, and
SHA-256 digest.

## Reproducible build

On Linux or Windows Subsystem for Linux, install CMake 3.13 or newer, Ninja,
Python 3, Ruby, and the Ruby `getoptlong` package. The build requires the
official Arm GNU Toolchain 13.2.Rel1 (`arm-none-eabi-gcc` 13.2.1). If that exact
compiler is not already in `PATH`, the inherited CMake toolchain check can
download the official archive and validates its pinned checksum.

From a clean extraction:

```bash
chmod +x flight-commander/build-micoair743.sh
./flight-commander/build-micoair743.sh
```

The helper refuses an existing build directory, enables warnings-as-errors,
embeds the source revision and deterministic build epoch from the manifest,
builds only `MICOAIR743`, and runs the source/HEX verifier. A successful build
produces:

`build-flight-commander/Flight-Commander-Firmware-2.0.6-MICOAIR743.hex`

The resulting SHA-256 must equal the value in `RELEASE-MANIFEST.json`.

## Firmware behavior added by the fork

- Flight Commander identity and versioned capability negotiation over MSPv2
- UART and DroneCAN RTK GNSS status
- MAVLink/MSP RTCM3 reassembly, validation, and injection
- DroneCAN GNSS, RTK correction, battery, node-discovery, and configuration paths
- DroneCAN magnetometer and moving-baseline heading inputs
- weighted circular heading fusion connected to the attitude estimator
- onboard IST8310 CW90 orientation fixed in firmware

Build verification is not a substitute for prop-off bench testing and staged
flight validation. Follow `VALIDATION.md` before operational use.
