# Flight Commander Firmware Validation Gates

Every firmware checkpoint must pass the applicable gates below before it is
offered for hardware testing.

## Source and build

- clean, pinned source tree
- exact compiler and dependency versions recorded
- `MICOAIR743` release build completes without warnings promoted from new code
- firmware size and linker-region usage compared with the prior checkpoint
- all host unit tests pass
- generated settings and parameter-group versions are validated
- MSP compatibility responses are regression-tested

## Prop-off bench

- USB identity and automatic reconnect
- firmware, API, board, and target identity
- accelerometer, gyro, barometer, compass, GPS, rangefinder, and optical-flow
  status as fitted
- receiver channels, failsafe state, and mode activation
- motor numbering, mixer coefficients, direction selection, and output mapping
- voltage/current readings and calibration retention
- UART assignment and MAVLink telemetry/RC link
- OSD, SD-card logging, save/reboot, DFU, and recovery flashing
- configuration backup and restore through Flight Commander

## Flight feature

- feature disabled by default until its baseline behavior is verified
- deterministic exit and rollback behavior
- Blackbox fields/events sufficient to explain every state transition
- no regression in manual control, stabilization, navigation, RTH, or failsafe
- staged hover and mission evaluation against the last known-good image

Hardware observations are recorded separately from source/build results. A
successful compile is never treated as proof of flight behavior.
