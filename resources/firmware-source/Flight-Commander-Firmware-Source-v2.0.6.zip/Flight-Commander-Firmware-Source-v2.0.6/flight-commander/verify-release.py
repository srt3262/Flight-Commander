#!/usr/bin/env python3

"""Verify the Flight Commander MICOAIR743 source/HEX release contract."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import sys


VERSION = "2.0.6"
TARGET = "MICOAIR743"
EXPECTED_IDENTITY = b"FCFW" + bytes((1, 2, 0, 6, 9, 1, 0, 0xFF, 0x1F, 0, 0))


def fail(message: str) -> None:
    raise ValueError(message)


def require_text(path: Path, patterns: list[str], rejected: list[str] | None = None) -> None:
    text = path.read_text(encoding="utf-8")
    for pattern in patterns:
        if not re.search(pattern, text, re.MULTILINE):
            fail(f"{path}: required source contract is missing: {pattern}")
    for pattern in rejected or []:
        if re.search(pattern, text, re.MULTILINE):
            fail(f"{path}: forbidden source contract remains: {pattern}")


def parse_intel_hex(path: Path) -> tuple[dict[int, int], int]:
    memory: dict[int, int] = {}
    upper_address = 0
    record_count = 0
    saw_eof = False

    for line_number, raw_line in enumerate(path.read_text(encoding="ascii").splitlines(), 1):
        line = raw_line.strip()
        if not line.startswith(":"):
            fail(f"{path}:{line_number}: invalid Intel HEX record")
        try:
            record = bytes.fromhex(line[1:])
        except ValueError as error:
            fail(f"{path}:{line_number}: non-hexadecimal record: {error}")
        if len(record) < 5 or record[0] + 5 != len(record):
            fail(f"{path}:{line_number}: invalid byte count")
        if sum(record) & 0xFF:
            fail(f"{path}:{line_number}: checksum mismatch")

        count = record[0]
        address = (record[1] << 8) | record[2]
        record_type = record[3]
        data = record[4 : 4 + count]
        record_count += 1

        if record_type == 0x00:
            absolute = upper_address + address
            for offset, value in enumerate(data):
                location = absolute + offset
                if location in memory and memory[location] != value:
                    fail(f"{path}:{line_number}: conflicting data at 0x{location:08X}")
                memory[location] = value
        elif record_type == 0x01:
            if count != 0:
                fail(f"{path}:{line_number}: malformed EOF record")
            saw_eof = True
        elif record_type == 0x02:
            if count != 2:
                fail(f"{path}:{line_number}: malformed segment-address record")
            upper_address = int.from_bytes(data, "big") << 4
        elif record_type == 0x04:
            if count != 2:
                fail(f"{path}:{line_number}: malformed linear-address record")
            upper_address = int.from_bytes(data, "big") << 16
        elif record_type not in (0x03, 0x05):
            fail(f"{path}:{line_number}: unsupported record type {record_type}")

    if not saw_eof:
        fail(f"{path}: missing EOF record")
    return memory, record_count


def contains_contiguous(memory: dict[int, int], expected: bytes) -> bool:
    first = expected[0]
    for address, value in memory.items():
        if value == first and all(memory.get(address + offset) == byte for offset, byte in enumerate(expected)):
            return True
    return False


def verify_source(root: Path) -> None:
    require_text(
        root / "CMakeLists.txt",
        [r"set\(FLIGHT_COMMANDER_FIRMWARE_VERSION 2\.0\.6\)", r"FLIGHT_COMMANDER_SOURCE_REVISION"],
    )
    require_text(
        root / "src/main/build/flight_commander.h",
        [
            r"FLIGHT_COMMANDER_VERSION_MAJOR 2",
            r"FLIGHT_COMMANDER_VERSION_MINOR 0",
            r"FLIGHT_COMMANDER_VERSION_PATCH 6",
            r"FLIGHT_COMMANDER_CAPABILITIES \(\(uint32_t\)0x1FFFU\)",
        ],
    )
    require_text(
        root / "src/main/target/MICOAIR743/CMakeLists.txt",
        [r"target_stm32h743xi\(MICOAIR743(?:\s|$)"],
        [r"MICOAIR743_EXTMAG"],
    )
    require_text(
        root / "src/main/target/MICOAIR743/target.h",
        [r"#define MAG_I2C_BUS\s+BUS_I2C2", r"#define USE_DRONECAN"],
        [r"MICOAIR743_EXTMAG"],
    )
    require_text(
        root / "src/main/target/MICOAIR743/config.c",
        [r"compassConfigMutable\(\)->mag_align = CW90_DEG;"],
        [r"MICOAIR743_EXTMAG"],
    )
    require_text(
        root / "src/main/sensors/compass.c",
        [r"defined\(MICOAIR743\)[\s\S]+mag\.dev\.magAlign\.onBoard = CW90_DEG;"],
    )
    require_text(
        root / "src/main/flight/imu.c",
        [r"flightCommanderHeadingGetCorrection", r"absoluteHeadingEF"],
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", required=True, type=Path)
    parser.add_argument("--hex", required=True, type=Path, dest="hex_path")
    parser.add_argument("--manifest", type=Path)
    args = parser.parse_args()

    root = args.source_root.resolve()
    hex_path = args.hex_path.resolve()
    verify_source(root)

    digest = hashlib.sha256(hex_path.read_bytes()).hexdigest()
    memory, record_count = parse_intel_hex(hex_path)
    if not contains_contiguous(memory, EXPECTED_IDENTITY):
        fail("HEX does not contain the exact FCFW 2.0.6 / INAV 9.1.0 / 0x1FFF identity payload")
    if not contains_contiguous(memory, TARGET.encode("ascii")):
        fail(f"HEX does not contain the {TARGET} target identity")

    if args.manifest:
        manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
        expected = {
            "schema": 1,
            "product": "Flight Commander Firmware",
            "version": VERSION,
            "target": TARGET,
        }
        for key, value in expected.items():
            if manifest.get(key) != value:
                fail(f"manifest {key!r} is {manifest.get(key)!r}, expected {value!r}")
        artifact = manifest.get("artifact", {})
        if artifact.get("filename") != hex_path.name:
            fail("manifest artifact filename does not match the HEX")
        if artifact.get("sha256") != digest:
            fail("manifest SHA-256 does not match the HEX")
        if artifact.get("bytes") != hex_path.stat().st_size:
            fail("manifest byte count does not match the HEX")

    print(
        f"Verified {hex_path.name}: {hex_path.stat().st_size} bytes, "
        f"{record_count} Intel HEX records, SHA-256 {digest}"
    )
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as error:
        print(f"verification failed: {error}", file=sys.stderr)
        sys.exit(1)
